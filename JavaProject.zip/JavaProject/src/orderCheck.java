
public class orderCheck {
	
	public orderCheck(int num)
	{
		
	}
}
